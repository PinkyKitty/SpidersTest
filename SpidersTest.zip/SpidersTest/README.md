Please don't steal any texutures in this texuturepack
All files here are owned by PinkCat.
